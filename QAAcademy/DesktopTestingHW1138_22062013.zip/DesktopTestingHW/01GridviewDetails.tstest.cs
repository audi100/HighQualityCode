using Telerik.WebAii.Controls.Xaml.Wpf;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;
using ArtOfTest.WebAii.Wpf;

namespace DesktopTestingHW
{
    //
    // You can add custom execution steps by simply
    // adding a void function and decorating it with the [CodedStep] 
    // attribute to the test method. 
    // Those steps will automatically show up in the test steps on save.
    //
    // The BaseWebAiiTest exposes all key objects that you can use
    // to access the current testcase context. [i.e. ActiveBrowser, Find ..etc]
    //
    // Data driven tests can use the Data[columnIndex] or Data["columnName"] 
    // to access data for a specific data iteration.
    //
    // Example:
    //
    // [CodedStep("MyCustom Step Description")]
    // public void MyCustomStep()
    // {
    //        // Custom code goes here
    //      Applications.Spreadsheetexe.Book1__Spreadsheet.InsertTabitem.User.Click();    
    // }
    //
        

    public class _1GridviewDetails : BaseWebAiiTest
    {
        #region [ Dynamic Applications Reference ]

        private Applications _applications;

        /// <summary>
        /// Gets the Applications object that has references
        /// to all the elements, windows or regions
        /// in this project.
        /// </summary>
        public Applications Applications
        {
            get
            {
                if (_applications == null)
                {
                    _applications = new Applications(Manager.Current);
                }
                return _applications;
            }
        }

        #endregion
        
        // Add your test methods here...
    
        //[CodedStep(@"New Coded Step")]
        //public void _01GridviewDetails_CodedStep()
        //{
            //Manager.Desktop.KeyBoard.KeyPress(System.Windows.Forms.Keys.Escape); 
        //}
    
        [CodedStep(@"New Coded Step")]
        public void _01GridviewDetails_CodedStep()
        {
            Manager.Desktop.KeyBoard.KeyPress(System.Windows.Forms.Keys.Escape); 
        }
    
        [CodedStep(@"LeftClick on FadeInImageImage")]
        public void _01GridviewDetails_CodedStep1()
        {
            // LeftClick on FadeInImageImage
            Applications.WPF_Demosexe.WPF_Controls_Examples__Grid_Chart_Scheduler_Map_Code_Samples.FadeInImageImage.User.Click(ArtOfTest.WebAii.Core.MouseClickType.LeftClick, 93, 29, ArtOfTest.Common.OffsetReference.TopLeftCorner, ArtOfTest.Common.ActionPointUnitType.Percentage, ((System.Windows.Forms.Keys)(0)));
            
        }
    }
}
