#navigation
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")

sleep(5)
while(exists ("1371884043973.png")):
    click("1371884043973.png")



