#navigation
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
sleep(5)
type(Key.F6)
type("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html")
type(Key.ENTER)

sleep(5)

dragDrop("Rome.png", "Italy.png")
assert(exists("ItalyRome.png"))
        
dragDrop("Madrid.png", "Spain.png")
assert(exists("SpainMadrid.png"))
dragDrop("Seoul.png", "bouthKorea.png")
assert(exists("SouthKoreaSe.png"))
dragDrop("Washington.png", "UnitedStates.png")
assert(exists("UnitedStates-1.png"))
dragDrop("Oslo-1.png", "Norway.png")
assert(exists("NorwayOslo.png"))

dragDrop("Stockholm-1.png", "Sweden-1.png")
assert(exists("SwedenStockh.png"))
dragDrop("Copenhagen.png", "Denmark.png")
assert(exists("DenmarkCopen.png"))

click("1371802164341.png")
