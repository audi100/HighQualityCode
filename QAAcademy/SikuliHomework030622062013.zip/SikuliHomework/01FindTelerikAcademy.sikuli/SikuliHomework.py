openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
sleep(5)
type(Key.F6)
type("http:/google.com/")
type(Key.ENTER)
sleep(5)
type("Telerik academy")
type(Key.ENTER)
telerikAcademy="TelerikAcade.png"

sleep(5)
assert(exists(telerikAcademy))

click("1371801662893.png")