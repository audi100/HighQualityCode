#navigation


openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
sleep(5)
type(Key.F6)
type("http:/sikuli.org/")
type(Key.ENTER)

sleep(5)
videoRegion=Region(389,261,81,28)
menuRegion=Region(146,253,917,45)
menuRegion.hover(videoRegion)

#click("1371802164341.png")
