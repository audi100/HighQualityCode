#navigation
openApp("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
sleep(5)
type(Key.F6)
type("http:/google.com/")
type(Key.ENTER)

sleep(5)

gRegion=Region(499,315,71,81)
gRegion.highlight()
googleNewRegion=Region(479,295,325,135);
googleNewRegion.highlight()
sleep(5)
type(Key.ENTER)
click("1371802164341-1.png")

