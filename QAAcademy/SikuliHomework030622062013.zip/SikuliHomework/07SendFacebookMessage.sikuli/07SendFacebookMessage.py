click("I.png")
click("MIQBTETENOBO.png")
sleep(5)
click(Pattern("H00cbo6uce.png").targetOffset(-12,28))
type("Sveto")
type(Key.ENTER)
click(Pattern("H00cbo6uce.png").targetOffset(-15,64))
type("Test message for Sikuli homework")
type(Key.ENTER)
sleep(2)
click("1371887540192.png")
type("Test message for Sikuli homework 2")
type(Key.ENTER)
sleep(2)
click("1371887540192.png")
type("Test message for Sikuli homework 3")
type(Key.ENTER)
sleep(2)
click("1371887540192.png")
type("Test message for Sikuli homework 4")
type(Key.ENTER)










