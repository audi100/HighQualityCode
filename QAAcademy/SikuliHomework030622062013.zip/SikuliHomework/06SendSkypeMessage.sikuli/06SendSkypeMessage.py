click("1371898951501.png")
searchBar="earthprogram.png"
wait(searchBar)
type("skype")
click("skype.png")
sleep(5)
friendName="SvediSVS-1.png"
wait(friendName)
click(friendName)
sendMessageBar="Sendamessage.png"
click(sendMessageBar)
type("Test")
sleep(2)
click("1371884915278.png")






